---
name: bosch-brand-guidelines
description: Apply Bosch-branded frontend styling for web pages and UI components using Tailwind and brand tokens. Use when creating or restyling HTML/React interfaces to match Bosch visual language, including header banner treatment, Bosch Sans font import from CDN, and shared design tokens for color, radius, and shadow.
---

# Bosch Brand Guidelines

Use this skill to make UI output consistent with the Bosch-style system used by `src/api/static/index.html`.

## Apply Brand Base

1. Use Tailwind-first styling. Prefer utility classes and `@theme` tokens over ad hoc inline styles.
2. Load Bosch Sans via CDN `@font-face` definitions (Regular, Bold, RegularItalic, BoldItalic).
3. Set font stack with `--font-sans: boschsans, ...` so all UI inherits the brand family.
4. Use the header banner asset from `assets/header-banner.svg` as the top strip background.

## Start Template

Use this base in Tailwind v4 environments:

```css
@font-face {
  font-family: "boschsans";
  font-weight: 400;
  src: url(https://brandguide-cdn.azureedge.net/fonts/BoschSans-Regular.woff2) format("woff2"),
       url(https://brandguide-cdn.azureedge.net/fonts/BoschSans-Regular.woff) format("woff");
  font-display: swap;
}

@font-face {
  font-family: "boschsans";
  font-weight: 700;
  src: url(https://brandguide-cdn.azureedge.net/fonts/BoschSans-Bold.woff2) format("woff2"),
       url(https://brandguide-cdn.azureedge.net/fonts/BoschSans-Bold.woff) format("woff");
  font-display: swap;
}

@font-face {
  font-family: "boschsans";
  font-weight: 400;
  font-style: italic;
  src: url(https://brandguide-cdn.azureedge.net/fonts/BoschSans-RegularItalic.woff2) format("woff2"),
       url(https://brandguide-cdn.azureedge.net/fonts/BoschSans-RegularItalic.woff) format("woff");
  font-display: swap;
}

@font-face {
  font-family: "boschsans";
  font-weight: 700;
  font-style: italic;
  src: url(https://brandguide-cdn.azureedge.net/fonts/BoschSans-BoldItalic.woff2) format("woff2"),
       url(https://brandguide-cdn.azureedge.net/fonts/BoschSans-BoldItalic.woff) format("woff");
  font-display: swap;
}

@theme {
  --font-sans: boschsans, "bosch-light", "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", Arial, sans-serif;
}
```

## Use Tokens Consistently

- Read `references/design-tokens.md` before building new pages.
- Prefer brand tokens (`blue`, `green`, `gray`, `red`, `yellow`, `turquoise`, `purple`) to default Tailwind palettes.
- Keep corners and elevation consistent with shared radius/shadow tokens.
- Use semantic choices:
  - Primary actions: `blue`
  - Success states: `green`
  - Errors/destructive actions: `red`
  - Neutral surfaces and text hierarchy: `gray`

## Header Banner Pattern

Use a thin top strip and page container pattern:

```html
<header>
  <div class="w-full h-1.5 overflow-hidden">
    <img src="/assets/header-banner.svg" class="w-full bg-center bg-cover" alt="" />
  </div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-6">
    <!-- page title, status badges, and metadata -->
  </div>
</header>
```

## Resources

- `assets/header-banner.svg`: Bosch-style colored header strip.
- `references/design-tokens.md`: Reusable color, radius, and shadow tokens derived from the source UI.
