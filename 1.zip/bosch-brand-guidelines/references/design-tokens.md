# Bosch Design Tokens

Use these tokens as defaults when building Bosch-branded pages.

## Typography

```css
--font-sans: boschsans, "bosch-light", "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", Arial, sans-serif;
```

## Core Color Tokens

```css
--color-blue-50: #007bc0;
--color-blue-70: #56b0ff;
--color-blue-95: #e8f1ff;

--color-green-50: #00884a;
--color-green-95: #e2f5e7;

--color-red-50: #ed0007;
--color-red-95: #ffecec;

--color-yellow-85: #ffcf00;
--color-yellow-95: #ffefd1;

--color-turquoise-50: #18837e;
--color-purple-40: #9e2896;

--color-gray-5: #101112;
--color-gray-20: #2e3033;
--color-gray-50: #71767c;
--color-gray-95: #eff1f2;

--color-white: #ffffff;
--color-black: #000000;
```

## Radius Tokens

The source UI mostly uses square to small-rounded controls. Use this set for consistency:

```css
--radius-none: 0;
--radius-sm: 0.125rem;
--radius-md: 0.375rem;
--radius-lg: 0.5rem;
--radius-pill: 9999px;
```

## Shadow Tokens

Use subtle elevation; avoid heavy shadows:

```css
--shadow-sm: 0 1px 2px rgba(16, 17, 18, 0.08);
--shadow-md: 0 4px 10px rgba(16, 17, 18, 0.12);
--shadow-lg: 0 10px 24px rgba(16, 17, 18, 0.16);
```

## Tailwind Mapping Hints

- `bg-blue-50 hover:bg-blue-70` for primary buttons
- `bg-green-95 text-green-800` for success notices
- `bg-red-95 text-red-800` for errors
- `bg-gray-95 text-gray-20` for neutral surfaces
- `rounded-md` for form inputs and cards
- `rounded-full` for badges
